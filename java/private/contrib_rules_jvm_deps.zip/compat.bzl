load("@contrib_rules_jvm_deps//:compat_repository.bzl", "compat_repository")

def compat_repositories():
    
    compat_repository(
        name = "com_github_nawforce_scala_json_rpc_upickle_json_serializer_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_github_nawforce_scala_json_rpc_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_github_oowekyala_ooxml_nice_xml_messages",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_github_pathikrit_better_files_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_github_spotbugs_spotbugs",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_github_spotbugs_spotbugs_annotations",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_github_stephenc_jcip_jcip_annotations",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_android_annotations",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_api_grpc_proto_google_common_protos",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_code_findbugs_jsr305",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_code_gson_gson",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_errorprone_error_prone_annotations",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_flogger_flogger",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_flogger_flogger_system_backend",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_googlejavaformat_google_java_format",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_guava_failureaccess",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_guava_guava",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_guava_listenablefuture",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_j2objc_j2objc_annotations",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_protobuf_protobuf_java",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_protobuf_protobuf_java_util",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_google_summit_summit_ast",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_lihaoyi_geny_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_lihaoyi_mainargs_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_lihaoyi_sourcecode_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_lihaoyi_ujson_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_lihaoyi_upack_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_lihaoyi_upickle_core_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_lihaoyi_upickle_implicits_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_lihaoyi_upickle_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "com_puppycrawl_tools_checkstyle",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "commons_beanutils_commons_beanutils",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "commons_cli_commons_cli",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "commons_codec_commons_codec",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "commons_collections_commons_collections",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "commons_logging_commons_logging",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "info_picocli_picocli",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_github_apex_dev_tools_apex_ls_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_github_apex_dev_tools_apex_parser",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_github_apex_dev_tools_apex_types_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_github_apex_dev_tools_outline_parser_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_github_apex_dev_tools_sobject_types",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_github_apex_dev_tools_standard_types",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_github_apex_dev_tools_vf_parser",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_grpc_grpc_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_grpc_grpc_context",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_grpc_grpc_core",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_grpc_grpc_netty",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_grpc_grpc_protobuf",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_grpc_grpc_protobuf_lite",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_grpc_grpc_services",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_grpc_grpc_stub",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_grpc_grpc_util",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_methvin_directory_watcher",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_methvin_directory_watcher_better_files_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_buffer",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_codec",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_codec_http",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_codec_http2",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_codec_socks",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_common",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_handler",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_handler_proxy",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_resolver",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_transport",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_netty_netty_transport_native_unix_common",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "io_perfmark_perfmark_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "javax_annotation_jsr250_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "jaxen_jaxen",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "junit_junit",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "me_tongfei_progressbar",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_java_dev_jna_jna",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sf_saxon_Saxon_HE",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_ant",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_apex",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_cli",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_coco",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_core",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_cpp",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_cs",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_css",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_dart",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_designer",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_dist",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_fortran",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_gherkin",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_go",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_groovy",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_html",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_java",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_javascript",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_jsp",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_julia",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_kotlin",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_languages_deps",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_lua",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_matlab",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_modelica",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_objectivec",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_perl",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_php",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_plsql",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_python",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_ruby",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_rust",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_scala_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_swift",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_tsql",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_velocity",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_visualforce",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "net_sourceforge_pmd_pmd_xml",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_antlr_antlr4_runtime",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_bcel_bcel",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_commons_commons_lang3",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_commons_commons_text",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_groovy_groovy",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_httpcomponents_client5_httpclient5",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_httpcomponents_core5_httpcore5",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_httpcomponents_core5_httpcore5_h2",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_httpcomponents_httpclient",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_httpcomponents_httpcore",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_logging_log4j_log4j_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_logging_log4j_log4j_core",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_maven_doxia_doxia_core",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_maven_doxia_doxia_logging_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_maven_doxia_doxia_module_xdoc",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_maven_doxia_doxia_sink_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_tomcat_annotations_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apache_xbean_xbean_reflect",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_apiguardian_apiguardian_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_checkerframework_checker_compat_qual",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_checkerframework_checker_qual",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_codehaus_mojo_animal_sniffer_annotations",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_codehaus_plexus_plexus_classworlds",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_codehaus_plexus_plexus_component_annotations",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_codehaus_plexus_plexus_container_default",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_codehaus_plexus_plexus_utils",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_danilopianini_gson_extras",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_dom4j_dom4j",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_hamcrest_hamcrest_core",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_javassist_javassist",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jetbrains_kotlin_kotlin_compiler",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jetbrains_kotlin_kotlin_reflect",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jetbrains_kotlin_kotlin_script_runtime",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jetbrains_kotlin_kotlin_stdlib",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jetbrains_kotlin_kotlin_stdlib_jdk7",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jetbrains_kotlin_kotlin_stdlib_jdk8",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jetbrains_kotlinx_kotlinx_coroutines_core_jvm",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jetbrains_annotations",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jline_jline",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_jsoup_jsoup",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_junit_jupiter_junit_jupiter_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_junit_jupiter_junit_jupiter_engine",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_junit_platform_junit_platform_commons",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_junit_platform_junit_platform_engine",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_junit_platform_junit_platform_launcher",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_junit_platform_junit_platform_reporting",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_junit_vintage_junit_vintage_engine",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_mozilla_rhino",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_opentest4j_opentest4j",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_ow2_asm_asm",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_ow2_asm_asm_analysis",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_ow2_asm_asm_commons",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_ow2_asm_asm_tree",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_ow2_asm_asm_util",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_pcollections_pcollections",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_reflections_reflections",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scala_js_scalajs_stubs_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scala_lang_modules_scala_collection_compat_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scala_lang_modules_scala_parallel_collections_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scala_lang_modules_scala_xml_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scala_lang_scala_library",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scala_lang_scala_reflect",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scalameta_common_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scalameta_io_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scalameta_parsers_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_scalameta_trees_2_13",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_slf4j_jul_to_slf4j",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_slf4j_slf4j_api",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_slf4j_slf4j_jdk14",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_slf4j_slf4j_simple",
        generating_repository = "contrib_rules_jvm_deps",
    )

    compat_repository(
        name = "org_xmlresolver_xmlresolver",
        generating_repository = "contrib_rules_jvm_deps",
    )
