load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_file")
load("@bazel_tools//tools/build_defs/repo:utils.bzl", "maybe")
def pinned_maven_install():
    pass
    http_file(
        name = "com_github_nawforce_scala_json_rpc_upickle_json_serializer_2_13_1_1_0",
        sha256 = "4ce9d100d26080a7b8813b6c3c6bc568c7c33b500b2b42120862c3f9fda926ff",
        urls = ["https://repo1.maven.org/maven2/com/github/nawforce/scala-json-rpc-upickle-json-serializer_2.13/1.1.0/scala-json-rpc-upickle-json-serializer_2.13-1.1.0.jar"],
        downloaded_file_path = "v1/com/github/nawforce/scala-json-rpc-upickle-json-serializer_2.13/1.1.0/scala-json-rpc-upickle-json-serializer_2.13-1.1.0.jar",
    )
    http_file(
        name = "com_github_nawforce_scala_json_rpc_2_13_1_1_0",
        sha256 = "0fcac451d102a687a1be2d8cb3ad4854a0beb9a26398f01db03d95f9851fa3e1",
        urls = ["https://repo1.maven.org/maven2/com/github/nawforce/scala-json-rpc_2.13/1.1.0/scala-json-rpc_2.13-1.1.0.jar"],
        downloaded_file_path = "v1/com/github/nawforce/scala-json-rpc_2.13/1.1.0/scala-json-rpc_2.13-1.1.0.jar",
    )
    http_file(
        name = "com_github_oowekyala_ooxml_nice_xml_messages_3_1",
        sha256 = "0b4ceb5b8362d43c9c6c49b1bd57f1c5da54d3c5c7c305fa39c0a04462bb4799",
        urls = ["https://repo1.maven.org/maven2/com/github/oowekyala/ooxml/nice-xml-messages/3.1/nice-xml-messages-3.1.jar"],
        downloaded_file_path = "v1/com/github/oowekyala/ooxml/nice-xml-messages/3.1/nice-xml-messages-3.1.jar",
    )
    http_file(
        name = "com_github_pathikrit_better_files_2_13_3_9_2",
        sha256 = "ba44cdde78320ea3800a8e99b5b3d0f3fc3bab0a9e9962c653b016d06e396022",
        urls = ["https://repo1.maven.org/maven2/com/github/pathikrit/better-files_2.13/3.9.2/better-files_2.13-3.9.2.jar"],
        downloaded_file_path = "v1/com/github/pathikrit/better-files_2.13/3.9.2/better-files_2.13-3.9.2.jar",
    )
    http_file(
        name = "com_github_spotbugs_spotbugs_4_8_6",
        sha256 = "69fde8787971a26b2372d416015d806bf7df4f847f7121bd5eeef239324cf180",
        urls = ["https://repo1.maven.org/maven2/com/github/spotbugs/spotbugs/4.8.6/spotbugs-4.8.6.jar"],
        downloaded_file_path = "v1/com/github/spotbugs/spotbugs/4.8.6/spotbugs-4.8.6.jar",
    )
    http_file(
        name = "com_github_spotbugs_spotbugs_annotations_4_8_6",
        sha256 = "4548b74a815ed44f5480ca4f06204a8b00809dc7e5f6a825a9edf18f40377b65",
        urls = ["https://repo1.maven.org/maven2/com/github/spotbugs/spotbugs-annotations/4.8.6/spotbugs-annotations-4.8.6.jar"],
        downloaded_file_path = "v1/com/github/spotbugs/spotbugs-annotations/4.8.6/spotbugs-annotations-4.8.6.jar",
    )
    http_file(
        name = "com_github_stephenc_jcip_jcip_annotations_1_0_1",
        sha256 = "4fccff8382aafc589962c4edb262f6aa595e34f1e11e61057d1c6a96e8fc7323",
        urls = ["https://repo1.maven.org/maven2/com/github/stephenc/jcip/jcip-annotations/1.0-1/jcip-annotations-1.0-1.jar"],
        downloaded_file_path = "v1/com/github/stephenc/jcip/jcip-annotations/1.0-1/jcip-annotations-1.0-1.jar",
    )
    http_file(
        name = "com_google_android_annotations_4_1_1_4",
        sha256 = "ba734e1e84c09d615af6a09d33034b4f0442f8772dec120efb376d86a565ae15",
        urls = ["https://repo1.maven.org/maven2/com/google/android/annotations/4.1.1.4/annotations-4.1.1.4.jar"],
        downloaded_file_path = "v1/com/google/android/annotations/4.1.1.4/annotations-4.1.1.4.jar",
    )
    http_file(
        name = "com_google_api_grpc_proto_google_common_protos_2_9_0",
        sha256 = "0d830380ec66bd7e25eee63aa0a5a08578e46ad187fb72d99b44d9ba22827f91",
        urls = ["https://repo1.maven.org/maven2/com/google/api/grpc/proto-google-common-protos/2.9.0/proto-google-common-protos-2.9.0.jar"],
        downloaded_file_path = "v1/com/google/api/grpc/proto-google-common-protos/2.9.0/proto-google-common-protos-2.9.0.jar",
    )
    http_file(
        name = "com_google_code_findbugs_jsr305_3_0_2",
        sha256 = "766ad2a0783f2687962c8ad74ceecc38a28b9f72a2d085ee438b7813e928d0c7",
        urls = ["https://repo1.maven.org/maven2/com/google/code/findbugs/jsr305/3.0.2/jsr305-3.0.2.jar"],
        downloaded_file_path = "v1/com/google/code/findbugs/jsr305/3.0.2/jsr305-3.0.2.jar",
    )
    http_file(
        name = "com_google_code_gson_gson_2_11_0",
        sha256 = "57928d6e5a6edeb2abd3770a8f95ba44dce45f3b23b7a9dc2b309c581552a78b",
        urls = ["https://repo1.maven.org/maven2/com/google/code/gson/gson/2.11.0/gson-2.11.0.jar"],
        downloaded_file_path = "v1/com/google/code/gson/gson/2.11.0/gson-2.11.0.jar",
    )
    http_file(
        name = "com_google_errorprone_error_prone_annotations_2_35_1",
        sha256 = "03b63fee38e3a86fda311af5a0357e64eea44909aab5251ed178119270508ff5",
        urls = ["https://repo1.maven.org/maven2/com/google/errorprone/error_prone_annotations/2.35.1/error_prone_annotations-2.35.1.jar"],
        downloaded_file_path = "v1/com/google/errorprone/error_prone_annotations/2.35.1/error_prone_annotations-2.35.1.jar",
    )
    http_file(
        name = "com_google_flogger_flogger_0_8",
        sha256 = "bebe7cd82be6c8d5208d6e960cd4344ea10672132ef06f5d4c71a48ab442b963",
        urls = ["https://repo1.maven.org/maven2/com/google/flogger/flogger/0.8/flogger-0.8.jar"],
        downloaded_file_path = "v1/com/google/flogger/flogger/0.8/flogger-0.8.jar",
    )
    http_file(
        name = "com_google_flogger_flogger_system_backend_0_8",
        sha256 = "eb4428e483c5332381778d78c6a19da63b4fef3fa7e40f62dadabea0d7600cb4",
        urls = ["https://repo1.maven.org/maven2/com/google/flogger/flogger-system-backend/0.8/flogger-system-backend-0.8.jar"],
        downloaded_file_path = "v1/com/google/flogger/flogger-system-backend/0.8/flogger-system-backend-0.8.jar",
    )
    http_file(
        name = "com_google_googlejavaformat_google_java_format_1_24_0",
        sha256 = "9a4e0b9f4ec4d71a8a1d3641fd481118100fda2eeab712dbdfd4b2a06e9de4ce",
        urls = ["https://repo1.maven.org/maven2/com/google/googlejavaformat/google-java-format/1.24.0/google-java-format-1.24.0.jar"],
        downloaded_file_path = "v1/com/google/googlejavaformat/google-java-format/1.24.0/google-java-format-1.24.0.jar",
    )
    http_file(
        name = "com_google_guava_failureaccess_1_0_1",
        sha256 = "a171ee4c734dd2da837e4b16be9df4661afab72a41adaf31eb84dfdaf936ca26",
        urls = ["https://repo1.maven.org/maven2/com/google/guava/failureaccess/1.0.1/failureaccess-1.0.1.jar"],
        downloaded_file_path = "v1/com/google/guava/failureaccess/1.0.1/failureaccess-1.0.1.jar",
    )
    http_file(
        name = "com_google_guava_guava_33_3_1_jre",
        sha256 = "4bf0e2c5af8e4525c96e8fde17a4f7307f97f8478f11c4c8e35a0e3298ae4e90",
        urls = ["https://repo1.maven.org/maven2/com/google/guava/guava/33.3.1-jre/guava-33.3.1-jre.jar"],
        downloaded_file_path = "v1/com/google/guava/guava/33.3.1-jre/guava-33.3.1-jre.jar",
    )
    http_file(
        name = "com_google_guava_listenablefuture_9999_0_empty_to_avoid_conflict_with_guava",
        sha256 = "b372a037d4230aa57fbeffdef30fd6123f9c0c2db85d0aced00c91b974f33f99",
        urls = ["https://repo1.maven.org/maven2/com/google/guava/listenablefuture/9999.0-empty-to-avoid-conflict-with-guava/listenablefuture-9999.0-empty-to-avoid-conflict-with-guava.jar"],
        downloaded_file_path = "v1/com/google/guava/listenablefuture/9999.0-empty-to-avoid-conflict-with-guava/listenablefuture-9999.0-empty-to-avoid-conflict-with-guava.jar",
    )
    http_file(
        name = "com_google_j2objc_j2objc_annotations_3_0_0",
        sha256 = "88241573467ddca44ffd4d74aa04c2bbfd11bf7c17e0c342c94c9de7a70a7c64",
        urls = ["https://repo1.maven.org/maven2/com/google/j2objc/j2objc-annotations/3.0.0/j2objc-annotations-3.0.0.jar"],
        downloaded_file_path = "v1/com/google/j2objc/j2objc-annotations/3.0.0/j2objc-annotations-3.0.0.jar",
    )
    http_file(
        name = "com_google_protobuf_protobuf_java_3_21_7",
        sha256 = "a204ec68748a7b26351ae37a311e8de468f248d1916d5f8dbe812c1289d0a0ff",
        urls = ["https://repo1.maven.org/maven2/com/google/protobuf/protobuf-java/3.21.7/protobuf-java-3.21.7.jar"],
        downloaded_file_path = "v1/com/google/protobuf/protobuf-java/3.21.7/protobuf-java-3.21.7.jar",
    )
    http_file(
        name = "com_google_protobuf_protobuf_java_util_3_25_5",
        sha256 = "dacc58b2c3d2fa8d4bddc1acb881e78d6cf7c137dd78bc1d67f6aca732436a8d",
        urls = ["https://repo1.maven.org/maven2/com/google/protobuf/protobuf-java-util/3.25.5/protobuf-java-util-3.25.5.jar"],
        downloaded_file_path = "v1/com/google/protobuf/protobuf-java-util/3.25.5/protobuf-java-util-3.25.5.jar",
    )
    http_file(
        name = "com_google_summit_summit_ast_2_4_0",
        sha256 = "5f411bad2a596357157b5032c48ff98823fef8090be6816ed1d1928d011da6dd",
        urls = ["https://repo1.maven.org/maven2/com/google/summit/summit-ast/2.4.0/summit-ast-2.4.0.jar"],
        downloaded_file_path = "v1/com/google/summit/summit-ast/2.4.0/summit-ast-2.4.0.jar",
    )
    http_file(
        name = "com_lihaoyi_geny_2_13_0_6_2",
        sha256 = "26017fa73ec7fa3cd2d44a4f5d3462c58cd6ddebf7d42d40123768edf7dee43c",
        urls = ["https://repo1.maven.org/maven2/com/lihaoyi/geny_2.13/0.6.2/geny_2.13-0.6.2.jar"],
        downloaded_file_path = "v1/com/lihaoyi/geny_2.13/0.6.2/geny_2.13-0.6.2.jar",
    )
    http_file(
        name = "com_lihaoyi_mainargs_2_13_0_5_4",
        sha256 = "f22a85b990fc68747b8caa51394a308c2778e9b230d69a3cdd79bb8bd7d1b562",
        urls = ["https://repo1.maven.org/maven2/com/lihaoyi/mainargs_2.13/0.5.4/mainargs_2.13-0.5.4.jar"],
        downloaded_file_path = "v1/com/lihaoyi/mainargs_2.13/0.5.4/mainargs_2.13-0.5.4.jar",
    )
    http_file(
        name = "com_lihaoyi_sourcecode_2_13_0_4_4",
        sha256 = "bd4e99aef8267a410b6ed716c487cf5256f801425f158a8c9cbd056eb032d80d",
        urls = ["https://repo1.maven.org/maven2/com/lihaoyi/sourcecode_2.13/0.4.4/sourcecode_2.13-0.4.4.jar"],
        downloaded_file_path = "v1/com/lihaoyi/sourcecode_2.13/0.4.4/sourcecode_2.13-0.4.4.jar",
    )
    http_file(
        name = "com_lihaoyi_ujson_2_13_1_2_0",
        sha256 = "68474183a6ff657f97a91488e294cbe977b2a439fec216d5167700c72471f358",
        urls = ["https://repo1.maven.org/maven2/com/lihaoyi/ujson_2.13/1.2.0/ujson_2.13-1.2.0.jar"],
        downloaded_file_path = "v1/com/lihaoyi/ujson_2.13/1.2.0/ujson_2.13-1.2.0.jar",
    )
    http_file(
        name = "com_lihaoyi_upack_2_13_1_2_0",
        sha256 = "1ed89d975c11ca0c87398f57e29ace72ff00835ba87b504a83c4190d17416c26",
        urls = ["https://repo1.maven.org/maven2/com/lihaoyi/upack_2.13/1.2.0/upack_2.13-1.2.0.jar"],
        downloaded_file_path = "v1/com/lihaoyi/upack_2.13/1.2.0/upack_2.13-1.2.0.jar",
    )
    http_file(
        name = "com_lihaoyi_upickle_core_2_13_1_2_0",
        sha256 = "503d9d2687053a401f974e902ed095e7534f11f9b06448e03543f72c02f4e6bd",
        urls = ["https://repo1.maven.org/maven2/com/lihaoyi/upickle-core_2.13/1.2.0/upickle-core_2.13-1.2.0.jar"],
        downloaded_file_path = "v1/com/lihaoyi/upickle-core_2.13/1.2.0/upickle-core_2.13-1.2.0.jar",
    )
    http_file(
        name = "com_lihaoyi_upickle_implicits_2_13_1_2_0",
        sha256 = "31d16e260f6eae6c4172f430f2c0711f669cd9dff576aadd1370b8bc5472f8d4",
        urls = ["https://repo1.maven.org/maven2/com/lihaoyi/upickle-implicits_2.13/1.2.0/upickle-implicits_2.13-1.2.0.jar"],
        downloaded_file_path = "v1/com/lihaoyi/upickle-implicits_2.13/1.2.0/upickle-implicits_2.13-1.2.0.jar",
    )
    http_file(
        name = "com_lihaoyi_upickle_2_13_1_2_0",
        sha256 = "eba8ec18d8284cfcb10395842c254280b46f97ea2aca7f48b2b3db20205bae6f",
        urls = ["https://repo1.maven.org/maven2/com/lihaoyi/upickle_2.13/1.2.0/upickle_2.13-1.2.0.jar"],
        downloaded_file_path = "v1/com/lihaoyi/upickle_2.13/1.2.0/upickle_2.13-1.2.0.jar",
    )
    http_file(
        name = "com_puppycrawl_tools_checkstyle_10_20_2",
        sha256 = "0a6130fa80830626723a62a216e6c4df14a412455d3461631531bb79e5a3fed0",
        urls = ["https://repo1.maven.org/maven2/com/puppycrawl/tools/checkstyle/10.20.2/checkstyle-10.20.2.jar"],
        downloaded_file_path = "v1/com/puppycrawl/tools/checkstyle/10.20.2/checkstyle-10.20.2.jar",
    )
    http_file(
        name = "commons_beanutils_commons_beanutils_1_9_4",
        sha256 = "7d938c81789028045c08c065e94be75fc280527620d5bd62b519d5838532368a",
        urls = ["https://repo1.maven.org/maven2/commons-beanutils/commons-beanutils/1.9.4/commons-beanutils-1.9.4.jar"],
        downloaded_file_path = "v1/commons-beanutils/commons-beanutils/1.9.4/commons-beanutils-1.9.4.jar",
    )
    http_file(
        name = "commons_cli_commons_cli_1_9_0",
        sha256 = "d3d530d0f28fd0fbbffe2b0b338f70e8cb96f1605579e2e3abd4db29cac24e69",
        urls = ["https://repo1.maven.org/maven2/commons-cli/commons-cli/1.9.0/commons-cli-1.9.0.jar"],
        downloaded_file_path = "v1/commons-cli/commons-cli/1.9.0/commons-cli-1.9.0.jar",
    )
    http_file(
        name = "commons_codec_commons_codec_1_15",
        sha256 = "b3e9f6d63a790109bf0d056611fbed1cf69055826defeb9894a71369d246ed63",
        urls = ["https://repo1.maven.org/maven2/commons-codec/commons-codec/1.15/commons-codec-1.15.jar"],
        downloaded_file_path = "v1/commons-codec/commons-codec/1.15/commons-codec-1.15.jar",
    )
    http_file(
        name = "commons_collections_commons_collections_3_2_2",
        sha256 = "eeeae917917144a68a741d4c0dff66aa5c5c5fd85593ff217bced3fc8ca783b8",
        urls = ["https://repo1.maven.org/maven2/commons-collections/commons-collections/3.2.2/commons-collections-3.2.2.jar"],
        downloaded_file_path = "v1/commons-collections/commons-collections/3.2.2/commons-collections-3.2.2.jar",
    )
    http_file(
        name = "commons_logging_commons_logging_1_2",
        sha256 = "daddea1ea0be0f56978ab3006b8ac92834afeefbd9b7e4e6316fca57df0fa636",
        urls = ["https://repo1.maven.org/maven2/commons-logging/commons-logging/1.2/commons-logging-1.2.jar"],
        downloaded_file_path = "v1/commons-logging/commons-logging/1.2/commons-logging-1.2.jar",
    )
    http_file(
        name = "info_picocli_picocli_4_7_6",
        sha256 = "ed441183f309b93f104ca9e071e314a4062a893184e18a3c7ad72ec9cba12ba0",
        urls = ["https://repo1.maven.org/maven2/info/picocli/picocli/4.7.6/picocli-4.7.6.jar"],
        downloaded_file_path = "v1/info/picocli/picocli/4.7.6/picocli-4.7.6.jar",
    )
    http_file(
        name = "io_github_apex_dev_tools_apex_ls_2_13_6_0_1",
        sha256 = "564b7426c012c4e71e2cb9564fb60fea98951f0c35a3d99d05f96e82066356f2",
        urls = ["https://repo1.maven.org/maven2/io/github/apex-dev-tools/apex-ls_2.13/6.0.1/apex-ls_2.13-6.0.1.jar"],
        downloaded_file_path = "v1/io/github/apex-dev-tools/apex-ls_2.13/6.0.1/apex-ls_2.13-6.0.1.jar",
    )
    http_file(
        name = "io_github_apex_dev_tools_apex_parser_4_4_1",
        sha256 = "3e293a3cdef4a54e1848858546ea3b9ca29f30f8aaa518ca01c31b708bc09a44",
        urls = ["https://repo1.maven.org/maven2/io/github/apex-dev-tools/apex-parser/4.4.1/apex-parser-4.4.1.jar"],
        downloaded_file_path = "v1/io/github/apex-dev-tools/apex-parser/4.4.1/apex-parser-4.4.1.jar",
    )
    http_file(
        name = "io_github_apex_dev_tools_apex_types_2_13_1_3_0",
        sha256 = "9d5bbd48a29abfc704d026382f7c9bb08c8bf0b114efcd065a31fb222f84a90f",
        urls = ["https://repo1.maven.org/maven2/io/github/apex-dev-tools/apex-types_2.13/1.3.0/apex-types_2.13-1.3.0.jar"],
        downloaded_file_path = "v1/io/github/apex-dev-tools/apex-types_2.13/1.3.0/apex-types_2.13-1.3.0.jar",
    )
    http_file(
        name = "io_github_apex_dev_tools_outline_parser_2_13_1_3_0",
        sha256 = "e86854d0aed6b509134fd356ad7d28d7c181f0216e053384b80b662741176313",
        urls = ["https://repo1.maven.org/maven2/io/github/apex-dev-tools/outline-parser_2.13/1.3.0/outline-parser_2.13-1.3.0.jar"],
        downloaded_file_path = "v1/io/github/apex-dev-tools/outline-parser_2.13/1.3.0/outline-parser_2.13-1.3.0.jar",
    )
    http_file(
        name = "io_github_apex_dev_tools_sobject_types_65_0_0",
        sha256 = "bd0dbe2c21c30d9a691c7a319a297572fe1bbc8b24d5f6a1fca4ae8b9a171131",
        urls = ["https://repo1.maven.org/maven2/io/github/apex-dev-tools/sobject-types/65.0.0/sobject-types-65.0.0.jar"],
        downloaded_file_path = "v1/io/github/apex-dev-tools/sobject-types/65.0.0/sobject-types-65.0.0.jar",
    )
    http_file(
        name = "io_github_apex_dev_tools_standard_types_65_0_0",
        sha256 = "69598d1fc34eea6701ba0b4a89f6bd3d9b91d3786b790d63552bad49ad7d60d2",
        urls = ["https://repo1.maven.org/maven2/io/github/apex-dev-tools/standard-types/65.0.0/standard-types-65.0.0.jar"],
        downloaded_file_path = "v1/io/github/apex-dev-tools/standard-types/65.0.0/standard-types-65.0.0.jar",
    )
    http_file(
        name = "io_github_apex_dev_tools_vf_parser_1_1_0",
        sha256 = "9515efe1c7f81c205d01f508c82f432a72735d132fc6bb5a1ebd954d9f881457",
        urls = ["https://repo1.maven.org/maven2/io/github/apex-dev-tools/vf-parser/1.1.0/vf-parser-1.1.0.jar"],
        downloaded_file_path = "v1/io/github/apex-dev-tools/vf-parser/1.1.0/vf-parser-1.1.0.jar",
    )
    http_file(
        name = "io_grpc_grpc_api_1_68_2",
        sha256 = "56b2ff4ec64de0a57ecb3b97fa0e6af5d60d2b5dbd2f97271873a7c54d7b18ff",
        urls = ["https://repo1.maven.org/maven2/io/grpc/grpc-api/1.68.2/grpc-api-1.68.2.jar"],
        downloaded_file_path = "v1/io/grpc/grpc-api/1.68.2/grpc-api-1.68.2.jar",
    )
    http_file(
        name = "io_grpc_grpc_context_1_68_2",
        sha256 = "99925ffb2964c32ea2b34d88679b0c5afe37bd35df3be38f46f7398ea52d9a31",
        urls = ["https://repo1.maven.org/maven2/io/grpc/grpc-context/1.68.2/grpc-context-1.68.2.jar"],
        downloaded_file_path = "v1/io/grpc/grpc-context/1.68.2/grpc-context-1.68.2.jar",
    )
    http_file(
        name = "io_grpc_grpc_core_1_68_2",
        sha256 = "7715f557bd0bebc695c8fa639c36c7c3f297a168bbe4bf74f52762d923193a43",
        urls = ["https://repo1.maven.org/maven2/io/grpc/grpc-core/1.68.2/grpc-core-1.68.2.jar"],
        downloaded_file_path = "v1/io/grpc/grpc-core/1.68.2/grpc-core-1.68.2.jar",
    )
    http_file(
        name = "io_grpc_grpc_netty_1_68_2",
        sha256 = "9cf387944bd9a00f0cf2d3b77fa047f50e8ed2519de501e7f0ac1e8a69d363a3",
        urls = ["https://repo1.maven.org/maven2/io/grpc/grpc-netty/1.68.2/grpc-netty-1.68.2.jar"],
        downloaded_file_path = "v1/io/grpc/grpc-netty/1.68.2/grpc-netty-1.68.2.jar",
    )
    http_file(
        name = "io_grpc_grpc_protobuf_1_68_2",
        sha256 = "a83ee044f7edfaa2c2b414c6a27bc2c39b7755c8604cd626411084c757419c14",
        urls = ["https://repo1.maven.org/maven2/io/grpc/grpc-protobuf/1.68.2/grpc-protobuf-1.68.2.jar"],
        downloaded_file_path = "v1/io/grpc/grpc-protobuf/1.68.2/grpc-protobuf-1.68.2.jar",
    )
    http_file(
        name = "io_grpc_grpc_protobuf_lite_1_68_2",
        sha256 = "9229e4bf6ea3c9e6d2ccce1203eb006a144771e974d46b08e92887ae38b3c2d8",
        urls = ["https://repo1.maven.org/maven2/io/grpc/grpc-protobuf-lite/1.68.2/grpc-protobuf-lite-1.68.2.jar"],
        downloaded_file_path = "v1/io/grpc/grpc-protobuf-lite/1.68.2/grpc-protobuf-lite-1.68.2.jar",
    )
    http_file(
        name = "io_grpc_grpc_services_1_68_2",
        sha256 = "c4614f4bbcf1249cc4b91fbc1b40d6728437907d0f69297e93186c3408638c57",
        urls = ["https://repo1.maven.org/maven2/io/grpc/grpc-services/1.68.2/grpc-services-1.68.2.jar"],
        downloaded_file_path = "v1/io/grpc/grpc-services/1.68.2/grpc-services-1.68.2.jar",
    )
    http_file(
        name = "io_grpc_grpc_stub_1_68_2",
        sha256 = "92c1260947a407ae3ab2be0a7e0f5067a294708f1a038e5db45a8e3974e9cd00",
        urls = ["https://repo1.maven.org/maven2/io/grpc/grpc-stub/1.68.2/grpc-stub-1.68.2.jar"],
        downloaded_file_path = "v1/io/grpc/grpc-stub/1.68.2/grpc-stub-1.68.2.jar",
    )
    http_file(
        name = "io_grpc_grpc_util_1_68_2",
        sha256 = "e4b42d4702cb0eae39130c941f815c3015ac395182135b4cc3c4de98f0652816",
        urls = ["https://repo1.maven.org/maven2/io/grpc/grpc-util/1.68.2/grpc-util-1.68.2.jar"],
        downloaded_file_path = "v1/io/grpc/grpc-util/1.68.2/grpc-util-1.68.2.jar",
    )
    http_file(
        name = "io_methvin_directory_watcher_0_18_0",
        sha256 = "18f67869b0d31d39512623226220abeedd6bde486d5599e6256eab7975110754",
        urls = ["https://repo1.maven.org/maven2/io/methvin/directory-watcher/0.18.0/directory-watcher-0.18.0.jar"],
        downloaded_file_path = "v1/io/methvin/directory-watcher/0.18.0/directory-watcher-0.18.0.jar",
    )
    http_file(
        name = "io_methvin_directory_watcher_better_files_2_13_0_18_0",
        sha256 = "839d3d970babacb606bb2f2e8461c2d7c40f6e36920753c41bf9561ba638d128",
        urls = ["https://repo1.maven.org/maven2/io/methvin/directory-watcher-better-files_2.13/0.18.0/directory-watcher-better-files_2.13-0.18.0.jar"],
        downloaded_file_path = "v1/io/methvin/directory-watcher-better-files_2.13/0.18.0/directory-watcher-better-files_2.13-0.18.0.jar",
    )
    http_file(
        name = "io_netty_netty_buffer_4_1_110_Final",
        sha256 = "46d74e79125aacc055c31f18152fdc5d4a569aa8d60091203d0baa833973ac3c",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-buffer/4.1.110.Final/netty-buffer-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-buffer/4.1.110.Final/netty-buffer-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_codec_4_1_110_Final",
        sha256 = "9eccce9a8d827bb8ce84f9c3183fec58bd1c96a51010cf711297746034af3701",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-codec/4.1.110.Final/netty-codec-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-codec/4.1.110.Final/netty-codec-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_codec_http_4_1_110_Final",
        sha256 = "dc0d6af5054630a70ff0ef354f20aa7a6e46738c9fc5636ed3d4fe77e38bd48d",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-codec-http/4.1.110.Final/netty-codec-http-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-codec-http/4.1.110.Final/netty-codec-http-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_codec_http2_4_1_110_Final",
        sha256 = "b546c75445a487bb7bcd5a94779caecce33582cf7be31b8b39fc0e65b1ee26fc",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-codec-http2/4.1.110.Final/netty-codec-http2-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-codec-http2/4.1.110.Final/netty-codec-http2-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_codec_socks_4_1_110_Final",
        sha256 = "976052a3c9bb280bc6d99f3a29e6404677cf958c3de05b205093d38c006b880c",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-codec-socks/4.1.110.Final/netty-codec-socks-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-codec-socks/4.1.110.Final/netty-codec-socks-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_common_4_1_110_Final",
        sha256 = "9851ec66548b9e0d41164ce98943cdd4bbe305f68ddbd24eae52e4501a0d7b1a",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-common/4.1.110.Final/netty-common-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-common/4.1.110.Final/netty-common-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_handler_4_1_110_Final",
        sha256 = "d5a08d7de364912e4285968de4d4cce3f01da4bb048d5c6937e5f2af1f8e148a",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-handler/4.1.110.Final/netty-handler-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-handler/4.1.110.Final/netty-handler-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_handler_proxy_4_1_110_Final",
        sha256 = "ad54ab4fe9c47ef3e723d71251126db53e8db543871adb9eafc94446539eff52",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-handler-proxy/4.1.110.Final/netty-handler-proxy-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-handler-proxy/4.1.110.Final/netty-handler-proxy-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_resolver_4_1_110_Final",
        sha256 = "a2e9b4ae7caa92fc5bd747e11d1dec20d81b18fc00959554302244ac5c56ce70",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-resolver/4.1.110.Final/netty-resolver-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-resolver/4.1.110.Final/netty-resolver-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_transport_4_1_110_Final",
        sha256 = "a42dd68390ca14b4ff2d40628a096c76485b4adb7c19602d5289321a0669e704",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-transport/4.1.110.Final/netty-transport-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-transport/4.1.110.Final/netty-transport-4.1.110.Final.jar",
    )
    http_file(
        name = "io_netty_netty_transport_native_unix_common_4_1_110_Final",
        sha256 = "51717bb7471141950390c6713a449fdb1054d07e60737ee7dda7083796cdee48",
        urls = ["https://repo1.maven.org/maven2/io/netty/netty-transport-native-unix-common/4.1.110.Final/netty-transport-native-unix-common-4.1.110.Final.jar"],
        downloaded_file_path = "v1/io/netty/netty-transport-native-unix-common/4.1.110.Final/netty-transport-native-unix-common-4.1.110.Final.jar",
    )
    http_file(
        name = "io_perfmark_perfmark_api_0_27_0",
        sha256 = "c7b478503ec524e55df19b424d46d27c8a68aeb801664fadd4f069b71f52d0f6",
        urls = ["https://repo1.maven.org/maven2/io/perfmark/perfmark-api/0.27.0/perfmark-api-0.27.0.jar"],
        downloaded_file_path = "v1/io/perfmark/perfmark-api/0.27.0/perfmark-api-0.27.0.jar",
    )
    http_file(
        name = "javax_annotation_jsr250_api_1_0",
        sha256 = "a1a922d0d9b6d183ed3800dfac01d1e1eb159f0e8c6f94736931c1def54a941f",
        urls = ["https://repo1.maven.org/maven2/javax/annotation/jsr250-api/1.0/jsr250-api-1.0.jar"],
        downloaded_file_path = "v1/javax/annotation/jsr250-api/1.0/jsr250-api-1.0.jar",
    )
    http_file(
        name = "jaxen_jaxen_2_0_0",
        sha256 = "9499e487a66268f47b8307d130cd1e13a58392105e98a51f6a525db79c615cc5",
        urls = ["https://repo1.maven.org/maven2/jaxen/jaxen/2.0.0/jaxen-2.0.0.jar"],
        downloaded_file_path = "v1/jaxen/jaxen/2.0.0/jaxen-2.0.0.jar",
    )
    http_file(
        name = "junit_junit_4_13_2",
        sha256 = "8e495b634469d64fb8acfa3495a065cbacc8a0fff55ce1e31007be4c16dc57d3",
        urls = ["https://repo1.maven.org/maven2/junit/junit/4.13.2/junit-4.13.2.jar"],
        downloaded_file_path = "v1/junit/junit/4.13.2/junit-4.13.2.jar",
    )
    http_file(
        name = "me_tongfei_progressbar_0_9_5",
        sha256 = "a1a086fa66f85c49bb3ca701a78cebb33647f367d4a5be8588c784d56272cc6e",
        urls = ["https://repo1.maven.org/maven2/me/tongfei/progressbar/0.9.5/progressbar-0.9.5.jar"],
        downloaded_file_path = "v1/me/tongfei/progressbar/0.9.5/progressbar-0.9.5.jar",
    )
    http_file(
        name = "net_java_dev_jna_jna_5_12_1",
        sha256 = "91a814ac4f40d60dee91d842e1a8ad874c62197984403d0e3c30d39e55cf53b3",
        urls = ["https://repo1.maven.org/maven2/net/java/dev/jna/jna/5.12.1/jna-5.12.1.jar"],
        downloaded_file_path = "v1/net/java/dev/jna/jna/5.12.1/jna-5.12.1.jar",
    )
    http_file(
        name = "net_sf_saxon_Saxon_HE_12_4",
        sha256 = "575f8b696e3b6f9aa7a3bf01611b8bf1b84576b55ce29bc16656a53a147ef441",
        urls = ["https://repo1.maven.org/maven2/net/sf/saxon/Saxon-HE/12.4/Saxon-HE-12.4.jar"],
        downloaded_file_path = "v1/net/sf/saxon/Saxon-HE/12.4/Saxon-HE-12.4.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_ant_7_18_0",
        sha256 = "fdcabb3890b474507c21c6729d3a621ecff89f5b93e521566a50ad9899b0ef3f",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-ant/7.18.0/pmd-ant-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-ant/7.18.0/pmd-ant-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_apex_7_18_0",
        sha256 = "3e29d1d151a1cfed105d8d21884c86bfc8ab05586a35f1e9a4e2403cc266e5a0",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-apex/7.18.0/pmd-apex-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-apex/7.18.0/pmd-apex-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_cli_7_18_0",
        sha256 = "62b7bed8c2c3c9582f756329111712217f120ee13878e759ab5f79be04d69491",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-cli/7.18.0/pmd-cli-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-cli/7.18.0/pmd-cli-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_coco_7_18_0",
        sha256 = "f8111468a17cd574271dfd2d057b71841611fad5665977fa52ec116731687005",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-coco/7.18.0/pmd-coco-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-coco/7.18.0/pmd-coco-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_core_7_18_0",
        sha256 = "d485ba1583b6a82f8111caef4e3d952fdb5096f14587f069e83e9adf81539d1c",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-core/7.18.0/pmd-core-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-core/7.18.0/pmd-core-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_cpp_7_18_0",
        sha256 = "d8e358278827ef53881d5c3cadac2ded3a73fe405cc62fb66d7ff60a33141c38",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-cpp/7.18.0/pmd-cpp-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-cpp/7.18.0/pmd-cpp-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_cs_7_18_0",
        sha256 = "4d20c9891f8d679beaa8b97b2b5945ca44150e015c1bfe4035e9e8fec0a36b77",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-cs/7.18.0/pmd-cs-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-cs/7.18.0/pmd-cs-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_css_7_18_0",
        sha256 = "fc5c1a86a23341b8dd02f017086d8e0a7f1656eea080a285ebdf0eba0fd3a6f7",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-css/7.18.0/pmd-css-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-css/7.18.0/pmd-css-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_dart_7_18_0",
        sha256 = "1c9d49161a9286b6b9aaa69ad30e61840a03e2d91cc2a13f12732046c05e96ed",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-dart/7.18.0/pmd-dart-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-dart/7.18.0/pmd-dart-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_designer_7_10_0",
        sha256 = "c74f98d6effb835519355d5f54aa68465793468b618094c5be0479af5f1463e3",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-designer/7.10.0/pmd-designer-7.10.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-designer/7.10.0/pmd-designer-7.10.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_dist_7_18_0",
        sha256 = "f07601ac3bb6bcb0d27972f56b59dd38fc0616385a2f1d4064d427ed2b20d4a3",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-dist/7.18.0/pmd-dist-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-dist/7.18.0/pmd-dist-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_fortran_7_18_0",
        sha256 = "af05d309b54cdb53717031bf3e42f1802035e52f63de9a42bf440cf493285f36",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-fortran/7.18.0/pmd-fortran-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-fortran/7.18.0/pmd-fortran-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_gherkin_7_18_0",
        sha256 = "35aee816c37b9a85055c3812ae6d12a82418ac85b83d08d55c2913a450e4254f",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-gherkin/7.18.0/pmd-gherkin-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-gherkin/7.18.0/pmd-gherkin-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_go_7_18_0",
        sha256 = "04d054bcb05d0d32410b73d307b3aad58657267113accf0ccf23a87a6899ecd9",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-go/7.18.0/pmd-go-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-go/7.18.0/pmd-go-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_groovy_7_18_0",
        sha256 = "682703918000ccde43f215b1363ec43f2c94b53d0669b4e64a5ddfead1011d3b",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-groovy/7.18.0/pmd-groovy-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-groovy/7.18.0/pmd-groovy-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_html_7_18_0",
        sha256 = "8145631e1c48136c005fe94b6b924be3874aa09500a75a7db03cdcb474e76e4a",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-html/7.18.0/pmd-html-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-html/7.18.0/pmd-html-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_java_7_18_0",
        sha256 = "03e484ebfa3e0c043249e1d4fc917fc60c36f919a92c21c442f9e80c2f933de1",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-java/7.18.0/pmd-java-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-java/7.18.0/pmd-java-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_javascript_7_18_0",
        sha256 = "4ab1f87a9c9fe4a4295391fb92eddef2fe29e7bae0556db02c38f12eeb7b1575",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-javascript/7.18.0/pmd-javascript-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-javascript/7.18.0/pmd-javascript-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_jsp_7_18_0",
        sha256 = "e142b7b9394ccdec2aceb1479be5afe63391ced2643ed8652c16dbc373ab97c6",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-jsp/7.18.0/pmd-jsp-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-jsp/7.18.0/pmd-jsp-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_julia_7_18_0",
        sha256 = "31e5f03d25e3636815acadaa281ad38fab84e687fa641823aa4cf333c715e230",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-julia/7.18.0/pmd-julia-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-julia/7.18.0/pmd-julia-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_kotlin_7_18_0",
        sha256 = "c41a8d2fe2871ed5baaba2395cb3e9c37b4d96608ab7ed44210e268365594c72",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-kotlin/7.18.0/pmd-kotlin-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-kotlin/7.18.0/pmd-kotlin-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_lua_7_18_0",
        sha256 = "a2942d7b40d53c9e61ff41b4c8f4e2047dedfe94f79ce54ced6d192838e9745a",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-lua/7.18.0/pmd-lua-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-lua/7.18.0/pmd-lua-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_matlab_7_18_0",
        sha256 = "12524af90889ebbcd519f025b7e04877c76444d8eca8ada3bcb618fe3d83602b",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-matlab/7.18.0/pmd-matlab-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-matlab/7.18.0/pmd-matlab-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_modelica_7_18_0",
        sha256 = "476c0e14205a8d4d5269c55d25253cb7c7914227a6b5b001a2bb32cb7080b9eb",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-modelica/7.18.0/pmd-modelica-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-modelica/7.18.0/pmd-modelica-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_objectivec_7_18_0",
        sha256 = "1601a34c5b3f9eef9d15e449b2d96d672c77a905b5acaa766634f270b0b69bbb",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-objectivec/7.18.0/pmd-objectivec-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-objectivec/7.18.0/pmd-objectivec-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_perl_7_18_0",
        sha256 = "e839b009b8de0ff59ac6b73a5f62959735f0dbe0008ec6efc9628c8facfb5f8e",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-perl/7.18.0/pmd-perl-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-perl/7.18.0/pmd-perl-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_php_7_18_0",
        sha256 = "7448dfc93324f4fa82c9a0990f3d37a80b6d7f99a6eee8db9245ff84734abf84",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-php/7.18.0/pmd-php-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-php/7.18.0/pmd-php-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_plsql_7_18_0",
        sha256 = "bc5e6cba956783682142dc1bb5ffabde6d0ab7df5af08eebb419355e894f5501",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-plsql/7.18.0/pmd-plsql-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-plsql/7.18.0/pmd-plsql-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_python_7_18_0",
        sha256 = "17f7040429bec7cea8179782664e12ac8a9fafdab6c1a0a035803dbb2b7dba72",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-python/7.18.0/pmd-python-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-python/7.18.0/pmd-python-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_ruby_7_18_0",
        sha256 = "80f3e6b54556d81eafa8b6b404612711385539ddeaf68b2ea1bd8933b523d266",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-ruby/7.18.0/pmd-ruby-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-ruby/7.18.0/pmd-ruby-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_rust_7_18_0",
        sha256 = "3e312998443c786c6e85cb8dd6693f4b4d12dd0b588ecf9299f27918f261f9a1",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-rust/7.18.0/pmd-rust-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-rust/7.18.0/pmd-rust-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_scala_2_13_7_18_0",
        sha256 = "e3b5f06d1a164e7e547aceb621d6d342fe3a7baf6a072228d75a2371e77681b4",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-scala_2.13/7.18.0/pmd-scala_2.13-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-scala_2.13/7.18.0/pmd-scala_2.13-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_swift_7_18_0",
        sha256 = "147d5c2ccc79447843e184463743ea0dbed0aa3d07e0c53b914b853845cc669c",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-swift/7.18.0/pmd-swift-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-swift/7.18.0/pmd-swift-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_tsql_7_18_0",
        sha256 = "a0afd4c011d7792b4bb16f54af364553526ff06b98dd49a24c483636c66f4a11",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-tsql/7.18.0/pmd-tsql-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-tsql/7.18.0/pmd-tsql-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_velocity_7_18_0",
        sha256 = "10c68dbf169c00e0e4656e08be992fc94825c7b7d305bf63f23da4955f2b54b1",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-velocity/7.18.0/pmd-velocity-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-velocity/7.18.0/pmd-velocity-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_visualforce_7_18_0",
        sha256 = "5c1efbcf24587e0f274fa5e460a3e55ac5229228522bdddfb08a95a78a062078",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-visualforce/7.18.0/pmd-visualforce-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-visualforce/7.18.0/pmd-visualforce-7.18.0.jar",
    )
    http_file(
        name = "net_sourceforge_pmd_pmd_xml_7_18_0",
        sha256 = "f4316c7f0d26f1fa783fa00888f7f98c3c55df018307e0d80f8212c677a5cbea",
        urls = ["https://repo1.maven.org/maven2/net/sourceforge/pmd/pmd-xml/7.18.0/pmd-xml-7.18.0.jar"],
        downloaded_file_path = "v1/net/sourceforge/pmd/pmd-xml/7.18.0/pmd-xml-7.18.0.jar",
    )
    http_file(
        name = "org_antlr_antlr4_runtime_4_13_2",
        sha256 = "dd3e8a13a2d669bf84fb8d834de35ce4875f27157698d206241ec8488aadcaf7",
        urls = ["https://repo1.maven.org/maven2/org/antlr/antlr4-runtime/4.13.2/antlr4-runtime-4.13.2.jar"],
        downloaded_file_path = "v1/org/antlr/antlr4-runtime/4.13.2/antlr4-runtime-4.13.2.jar",
    )
    http_file(
        name = "org_apache_bcel_bcel_6_9_0",
        sha256 = "a119a4420350dea669acfd84120ecc7e5742dcabcc82b0b9f9755dc692335aa2",
        urls = ["https://repo1.maven.org/maven2/org/apache/bcel/bcel/6.9.0/bcel-6.9.0.jar"],
        downloaded_file_path = "v1/org/apache/bcel/bcel/6.9.0/bcel-6.9.0.jar",
    )
    http_file(
        name = "org_apache_commons_commons_lang3_3_14_0",
        sha256 = "7b96bf3ee68949abb5bc465559ac270e0551596fa34523fddf890ec418dde13c",
        urls = ["https://repo1.maven.org/maven2/org/apache/commons/commons-lang3/3.14.0/commons-lang3-3.14.0.jar"],
        downloaded_file_path = "v1/org/apache/commons/commons-lang3/3.14.0/commons-lang3-3.14.0.jar",
    )
    http_file(
        name = "org_apache_commons_commons_text_1_10_0",
        sha256 = "770cd903fa7b604d1f7ef7ba17f84108667294b2b478be8ed1af3bffb4ae0018",
        urls = ["https://repo1.maven.org/maven2/org/apache/commons/commons-text/1.10.0/commons-text-1.10.0.jar"],
        downloaded_file_path = "v1/org/apache/commons/commons-text/1.10.0/commons-text-1.10.0.jar",
    )
    http_file(
        name = "org_apache_groovy_groovy_5_0_2",
        sha256 = "1177a82e357b401a1fcbd401fa2aececbecd65b774f0c29bb517b95e1930a909",
        urls = ["https://repo1.maven.org/maven2/org/apache/groovy/groovy/5.0.2/groovy-5.0.2.jar"],
        downloaded_file_path = "v1/org/apache/groovy/groovy/5.0.2/groovy-5.0.2.jar",
    )
    http_file(
        name = "org_apache_httpcomponents_client5_httpclient5_5_1_3",
        sha256 = "28c759254f4e35319e078bb6ffea75676608dc12cb243b24fb3c8732522977fe",
        urls = ["https://repo1.maven.org/maven2/org/apache/httpcomponents/client5/httpclient5/5.1.3/httpclient5-5.1.3.jar"],
        downloaded_file_path = "v1/org/apache/httpcomponents/client5/httpclient5/5.1.3/httpclient5-5.1.3.jar",
    )
    http_file(
        name = "org_apache_httpcomponents_core5_httpcore5_5_1_3",
        sha256 = "f2bf2f2c7772169c9e30699719667ad30f9b46c4e9d7841907deb2d12d9923fe",
        urls = ["https://repo1.maven.org/maven2/org/apache/httpcomponents/core5/httpcore5/5.1.3/httpcore5-5.1.3.jar"],
        downloaded_file_path = "v1/org/apache/httpcomponents/core5/httpcore5/5.1.3/httpcore5-5.1.3.jar",
    )
    http_file(
        name = "org_apache_httpcomponents_core5_httpcore5_h2_5_1_3",
        sha256 = "d0e78ba15aa8ebe77982b660ac4b09a95d6e035dbdbea762577dc1c8e2935807",
        urls = ["https://repo1.maven.org/maven2/org/apache/httpcomponents/core5/httpcore5-h2/5.1.3/httpcore5-h2-5.1.3.jar"],
        downloaded_file_path = "v1/org/apache/httpcomponents/core5/httpcore5-h2/5.1.3/httpcore5-h2-5.1.3.jar",
    )
    http_file(
        name = "org_apache_httpcomponents_httpclient_4_5_13",
        sha256 = "6fe9026a566c6a5001608cf3fc32196641f6c1e5e1986d1037ccdbd5f31ef743",
        urls = ["https://repo1.maven.org/maven2/org/apache/httpcomponents/httpclient/4.5.13/httpclient-4.5.13.jar"],
        downloaded_file_path = "v1/org/apache/httpcomponents/httpclient/4.5.13/httpclient-4.5.13.jar",
    )
    http_file(
        name = "org_apache_httpcomponents_httpcore_4_4_14",
        sha256 = "f956209e450cb1d0c51776dfbd23e53e9dd8db9a1298ed62b70bf0944ba63b28",
        urls = ["https://repo1.maven.org/maven2/org/apache/httpcomponents/httpcore/4.4.14/httpcore-4.4.14.jar"],
        downloaded_file_path = "v1/org/apache/httpcomponents/httpcore/4.4.14/httpcore-4.4.14.jar",
    )
    http_file(
        name = "org_apache_logging_log4j_log4j_api_2_23_1",
        sha256 = "92ec1fd36ab3bc09de6198d2d7c0914685c0f7127ea931acc32fd2ecdd82ea89",
        urls = ["https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-api/2.23.1/log4j-api-2.23.1.jar"],
        downloaded_file_path = "v1/org/apache/logging/log4j/log4j-api/2.23.1/log4j-api-2.23.1.jar",
    )
    http_file(
        name = "org_apache_logging_log4j_log4j_core_2_23_1",
        sha256 = "7079368005fc34f56248f57f8a8a53361c3a53e9007d556dbc66fc669df081b5",
        urls = ["https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-core/2.23.1/log4j-core-2.23.1.jar"],
        downloaded_file_path = "v1/org/apache/logging/log4j/log4j-core/2.23.1/log4j-core-2.23.1.jar",
    )
    http_file(
        name = "org_apache_maven_doxia_doxia_core_1_12_0",
        sha256 = "5e49cd827bebbcea5829d3b3883d17ad1ce15ebd6394aeb50ad50d7dfd939fcd",
        urls = ["https://repo1.maven.org/maven2/org/apache/maven/doxia/doxia-core/1.12.0/doxia-core-1.12.0.jar"],
        downloaded_file_path = "v1/org/apache/maven/doxia/doxia-core/1.12.0/doxia-core-1.12.0.jar",
    )
    http_file(
        name = "org_apache_maven_doxia_doxia_logging_api_1_12_0",
        sha256 = "985306162c0a9f4c309d46109447f30f02bf6fc9bc16a3e039d59e1dabd0192f",
        urls = ["https://repo1.maven.org/maven2/org/apache/maven/doxia/doxia-logging-api/1.12.0/doxia-logging-api-1.12.0.jar"],
        downloaded_file_path = "v1/org/apache/maven/doxia/doxia-logging-api/1.12.0/doxia-logging-api-1.12.0.jar",
    )
    http_file(
        name = "org_apache_maven_doxia_doxia_module_xdoc_1_12_0",
        sha256 = "e8731ba00a4edd34b20eff9e4a729c2045c62cb796c3e491692607de4476ab01",
        urls = ["https://repo1.maven.org/maven2/org/apache/maven/doxia/doxia-module-xdoc/1.12.0/doxia-module-xdoc-1.12.0.jar"],
        downloaded_file_path = "v1/org/apache/maven/doxia/doxia-module-xdoc/1.12.0/doxia-module-xdoc-1.12.0.jar",
    )
    http_file(
        name = "org_apache_maven_doxia_doxia_sink_api_1_12_0",
        sha256 = "5dca6aaaa9e70d8a0766e143ddcf9db09de5fde0fbcc78cb635d74e764dfcca5",
        urls = ["https://repo1.maven.org/maven2/org/apache/maven/doxia/doxia-sink-api/1.12.0/doxia-sink-api-1.12.0.jar"],
        downloaded_file_path = "v1/org/apache/maven/doxia/doxia-sink-api/1.12.0/doxia-sink-api-1.12.0.jar",
    )
    http_file(
        name = "org_apache_tomcat_annotations_api_6_0_53",
        sha256 = "253829d3c12b7381d1044fc22c6436cff025fe0d459e4a329413e560a7d0dd13",
        urls = ["https://repo1.maven.org/maven2/org/apache/tomcat/annotations-api/6.0.53/annotations-api-6.0.53.jar"],
        downloaded_file_path = "v1/org/apache/tomcat/annotations-api/6.0.53/annotations-api-6.0.53.jar",
    )
    http_file(
        name = "org_apache_xbean_xbean_reflect_3_7",
        sha256 = "104e5e9bb5a669f86722f32281960700f7ec8e3209ef51b23eb9b6d23d1629cb",
        urls = ["https://repo1.maven.org/maven2/org/apache/xbean/xbean-reflect/3.7/xbean-reflect-3.7.jar"],
        downloaded_file_path = "v1/org/apache/xbean/xbean-reflect/3.7/xbean-reflect-3.7.jar",
    )
    http_file(
        name = "org_apiguardian_apiguardian_api_1_1_2",
        sha256 = "b509448ac506d607319f182537f0b35d71007582ec741832a1f111e5b5b70b38",
        urls = ["https://repo1.maven.org/maven2/org/apiguardian/apiguardian-api/1.1.2/apiguardian-api-1.1.2.jar"],
        downloaded_file_path = "v1/org/apiguardian/apiguardian-api/1.1.2/apiguardian-api-1.1.2.jar",
    )
    http_file(
        name = "org_checkerframework_checker_compat_qual_2_5_3",
        sha256 = "d76b9afea61c7c082908023f0cbc1427fab9abd2df915c8b8a3e7a509bccbc6d",
        urls = ["https://repo1.maven.org/maven2/org/checkerframework/checker-compat-qual/2.5.3/checker-compat-qual-2.5.3.jar"],
        downloaded_file_path = "v1/org/checkerframework/checker-compat-qual/2.5.3/checker-compat-qual-2.5.3.jar",
    )
    http_file(
        name = "org_checkerframework_checker_qual_3_43_0",
        sha256 = "3fbc2e98f05854c3df16df9abaa955b91b15b3ecac33623208ed6424640ef0f6",
        urls = ["https://repo1.maven.org/maven2/org/checkerframework/checker-qual/3.43.0/checker-qual-3.43.0.jar"],
        downloaded_file_path = "v1/org/checkerframework/checker-qual/3.43.0/checker-qual-3.43.0.jar",
    )
    http_file(
        name = "org_codehaus_mojo_animal_sniffer_annotations_1_21",
        sha256 = "2f25841c937e24959a57b630e2c4b8525b3d0f536f2e511c9b2bed30b1651d54",
        urls = ["https://repo1.maven.org/maven2/org/codehaus/mojo/animal-sniffer-annotations/1.21/animal-sniffer-annotations-1.21.jar"],
        downloaded_file_path = "v1/org/codehaus/mojo/animal-sniffer-annotations/1.21/animal-sniffer-annotations-1.21.jar",
    )
    http_file(
        name = "org_codehaus_plexus_plexus_classworlds_2_6_0",
        sha256 = "52f77c5ec49f787c9c417ebed5d6efd9922f44a202f217376e4f94c0d74f3549",
        urls = ["https://repo1.maven.org/maven2/org/codehaus/plexus/plexus-classworlds/2.6.0/plexus-classworlds-2.6.0.jar"],
        downloaded_file_path = "v1/org/codehaus/plexus/plexus-classworlds/2.6.0/plexus-classworlds-2.6.0.jar",
    )
    http_file(
        name = "org_codehaus_plexus_plexus_component_annotations_2_1_0",
        sha256 = "bde3617ce9b5bcf9584126046080043af6a4b3baea40a3b153f02e7bbc32acac",
        urls = ["https://repo1.maven.org/maven2/org/codehaus/plexus/plexus-component-annotations/2.1.0/plexus-component-annotations-2.1.0.jar"],
        downloaded_file_path = "v1/org/codehaus/plexus/plexus-component-annotations/2.1.0/plexus-component-annotations-2.1.0.jar",
    )
    http_file(
        name = "org_codehaus_plexus_plexus_container_default_2_1_0",
        sha256 = "6dceb1246b188153bdcb6f962d543d51ddb672cca07cad94a78fbabc9edf0a39",
        urls = ["https://repo1.maven.org/maven2/org/codehaus/plexus/plexus-container-default/2.1.0/plexus-container-default-2.1.0.jar"],
        downloaded_file_path = "v1/org/codehaus/plexus/plexus-container-default/2.1.0/plexus-container-default-2.1.0.jar",
    )
    http_file(
        name = "org_codehaus_plexus_plexus_utils_3_3_0",
        sha256 = "76d174792540e2775af94d03d10fb2d3c776e2cd0ac0ebf427d3e570072bb9ce",
        urls = ["https://repo1.maven.org/maven2/org/codehaus/plexus/plexus-utils/3.3.0/plexus-utils-3.3.0.jar"],
        downloaded_file_path = "v1/org/codehaus/plexus/plexus-utils/3.3.0/plexus-utils-3.3.0.jar",
    )
    http_file(
        name = "org_danilopianini_gson_extras_1_3_0",
        sha256 = "a8bec65d0eb9d5fcda6410eea9993104f8c0852f8024972d8662b4dac8258c1d",
        urls = ["https://repo1.maven.org/maven2/org/danilopianini/gson-extras/1.3.0/gson-extras-1.3.0.jar"],
        downloaded_file_path = "v1/org/danilopianini/gson-extras/1.3.0/gson-extras-1.3.0.jar",
    )
    http_file(
        name = "org_dom4j_dom4j_2_1_4",
        sha256 = "235a9167a8a199be04b5326d92927ca0adeb90d11f69fe2e821b34ce8433b591",
        urls = ["https://repo1.maven.org/maven2/org/dom4j/dom4j/2.1.4/dom4j-2.1.4.jar"],
        downloaded_file_path = "v1/org/dom4j/dom4j/2.1.4/dom4j-2.1.4.jar",
    )
    http_file(
        name = "org_hamcrest_hamcrest_core_1_3",
        sha256 = "66fdef91e9739348df7a096aa384a5685f4e875584cce89386a7a47251c4d8e9",
        urls = ["https://repo1.maven.org/maven2/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar"],
        downloaded_file_path = "v1/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar",
    )
    http_file(
        name = "org_javassist_javassist_3_28_0_GA",
        sha256 = "57d0a9e9286f82f4eaa851125186997f811befce0e2060ff0a15a77f5a9dd9a7",
        urls = ["https://repo1.maven.org/maven2/org/javassist/javassist/3.28.0-GA/javassist-3.28.0-GA.jar"],
        downloaded_file_path = "v1/org/javassist/javassist/3.28.0-GA/javassist-3.28.0-GA.jar",
    )
    http_file(
        name = "org_jetbrains_kotlin_kotlin_compiler_2_2_20",
        sha256 = "8546feb440ec2d59e00d475936523fcd3f528e21c7e8eb8a95e6de5044a6d496",
        urls = ["https://repo1.maven.org/maven2/org/jetbrains/kotlin/kotlin-compiler/2.2.20/kotlin-compiler-2.2.20.jar"],
        downloaded_file_path = "v1/org/jetbrains/kotlin/kotlin-compiler/2.2.20/kotlin-compiler-2.2.20.jar",
    )
    http_file(
        name = "org_jetbrains_kotlin_kotlin_reflect_1_6_10",
        sha256 = "3277ac102ae17aad10a55abec75ff5696c8d109790396434b496e75087854203",
        urls = ["https://repo1.maven.org/maven2/org/jetbrains/kotlin/kotlin-reflect/1.6.10/kotlin-reflect-1.6.10.jar"],
        downloaded_file_path = "v1/org/jetbrains/kotlin/kotlin-reflect/1.6.10/kotlin-reflect-1.6.10.jar",
    )
    http_file(
        name = "org_jetbrains_kotlin_kotlin_script_runtime_2_2_20",
        sha256 = "5c8bd5dd7ae1ea2eeb2778fdbeaa19a562184975f6cab8a0bb6779e4190731ae",
        urls = ["https://repo1.maven.org/maven2/org/jetbrains/kotlin/kotlin-script-runtime/2.2.20/kotlin-script-runtime-2.2.20.jar"],
        downloaded_file_path = "v1/org/jetbrains/kotlin/kotlin-script-runtime/2.2.20/kotlin-script-runtime-2.2.20.jar",
    )
    http_file(
        name = "org_jetbrains_kotlin_kotlin_stdlib_2_2_20",
        sha256 = "8836ccffd3585fadda9901244b20d42901d2f3cd581058d8434e2ffabcf3a3e7",
        urls = ["https://repo1.maven.org/maven2/org/jetbrains/kotlin/kotlin-stdlib/2.2.20/kotlin-stdlib-2.2.20.jar"],
        downloaded_file_path = "v1/org/jetbrains/kotlin/kotlin-stdlib/2.2.20/kotlin-stdlib-2.2.20.jar",
    )
    http_file(
        name = "org_jetbrains_kotlin_kotlin_stdlib_jdk7_2_2_20",
        sha256 = "3bd26ecb6d12978c5c4e0b41f76c9ff551fac2a5e6268427a9d2a0cdf8a5ad91",
        urls = ["https://repo1.maven.org/maven2/org/jetbrains/kotlin/kotlin-stdlib-jdk7/2.2.20/kotlin-stdlib-jdk7-2.2.20.jar"],
        downloaded_file_path = "v1/org/jetbrains/kotlin/kotlin-stdlib-jdk7/2.2.20/kotlin-stdlib-jdk7-2.2.20.jar",
    )
    http_file(
        name = "org_jetbrains_kotlin_kotlin_stdlib_jdk8_2_2_20",
        sha256 = "c314177935d8dc2eda879507117f25d6de56f6c57ede99416b14cd622bb9e09d",
        urls = ["https://repo1.maven.org/maven2/org/jetbrains/kotlin/kotlin-stdlib-jdk8/2.2.20/kotlin-stdlib-jdk8-2.2.20.jar"],
        downloaded_file_path = "v1/org/jetbrains/kotlin/kotlin-stdlib-jdk8/2.2.20/kotlin-stdlib-jdk8-2.2.20.jar",
    )
    http_file(
        name = "org_jetbrains_kotlinx_kotlinx_coroutines_core_jvm_1_8_0",
        sha256 = "9860906a1937490bf5f3b06d2f0e10ef451e65b95b269f22daf68a3d1f5065c5",
        urls = ["https://repo1.maven.org/maven2/org/jetbrains/kotlinx/kotlinx-coroutines-core-jvm/1.8.0/kotlinx-coroutines-core-jvm-1.8.0.jar"],
        downloaded_file_path = "v1/org/jetbrains/kotlinx/kotlinx-coroutines-core-jvm/1.8.0/kotlinx-coroutines-core-jvm-1.8.0.jar",
    )
    http_file(
        name = "org_jetbrains_annotations_23_0_0",
        sha256 = "7b0f19724082cbfcbc66e5abea2b9bc92cf08a1ea11e191933ed43801eb3cd05",
        urls = ["https://repo1.maven.org/maven2/org/jetbrains/annotations/23.0.0/annotations-23.0.0.jar"],
        downloaded_file_path = "v1/org/jetbrains/annotations/23.0.0/annotations-23.0.0.jar",
    )
    http_file(
        name = "org_jline_jline_3_21_0",
        sha256 = "1e7d63a2bd1c26354ca1987e55469ea4327c4a3845c10d7a7790ca9729c49c02",
        urls = ["https://repo1.maven.org/maven2/org/jline/jline/3.21.0/jline-3.21.0.jar"],
        downloaded_file_path = "v1/org/jline/jline/3.21.0/jline-3.21.0.jar",
    )
    http_file(
        name = "org_jsoup_jsoup_1_21_2",
        sha256 = "f05496e255734759f0d4b5632da7b24f81313147c78c69e90ad045d096191344",
        urls = ["https://repo1.maven.org/maven2/org/jsoup/jsoup/1.21.2/jsoup-1.21.2.jar"],
        downloaded_file_path = "v1/org/jsoup/jsoup/1.21.2/jsoup-1.21.2.jar",
    )
    http_file(
        name = "org_junit_jupiter_junit_jupiter_api_5_11_3",
        sha256 = "5d8147a60f49453973e250ed68701b7ff055964fe2462fc2cb1ec1d6d44889ba",
        urls = ["https://repo1.maven.org/maven2/org/junit/jupiter/junit-jupiter-api/5.11.3/junit-jupiter-api-5.11.3.jar"],
        downloaded_file_path = "v1/org/junit/jupiter/junit-jupiter-api/5.11.3/junit-jupiter-api-5.11.3.jar",
    )
    http_file(
        name = "org_junit_jupiter_junit_jupiter_engine_5_11_3",
        sha256 = "e62420c99f7c0d59a2159a2ef63e61877e9c80bd722c03ca8bf3bdcea050a589",
        urls = ["https://repo1.maven.org/maven2/org/junit/jupiter/junit-jupiter-engine/5.11.3/junit-jupiter-engine-5.11.3.jar"],
        downloaded_file_path = "v1/org/junit/jupiter/junit-jupiter-engine/5.11.3/junit-jupiter-engine-5.11.3.jar",
    )
    http_file(
        name = "org_junit_platform_junit_platform_commons_1_11_3",
        sha256 = "be262964b0b6b48de977c61d4f931df8cf61e80e750cc3f3a0a39cdd21c1008c",
        urls = ["https://repo1.maven.org/maven2/org/junit/platform/junit-platform-commons/1.11.3/junit-platform-commons-1.11.3.jar"],
        downloaded_file_path = "v1/org/junit/platform/junit-platform-commons/1.11.3/junit-platform-commons-1.11.3.jar",
    )
    http_file(
        name = "org_junit_platform_junit_platform_engine_1_11_3",
        sha256 = "0043f72f611664735da8dc9a308bf12ecd2236b05339351c4741edb4d8fab0da",
        urls = ["https://repo1.maven.org/maven2/org/junit/platform/junit-platform-engine/1.11.3/junit-platform-engine-1.11.3.jar"],
        downloaded_file_path = "v1/org/junit/platform/junit-platform-engine/1.11.3/junit-platform-engine-1.11.3.jar",
    )
    http_file(
        name = "org_junit_platform_junit_platform_launcher_1_11_3",
        sha256 = "b4727459201b0011beb0742bd807421a1fc8426b116193031ed87825bc2d4f04",
        urls = ["https://repo1.maven.org/maven2/org/junit/platform/junit-platform-launcher/1.11.3/junit-platform-launcher-1.11.3.jar"],
        downloaded_file_path = "v1/org/junit/platform/junit-platform-launcher/1.11.3/junit-platform-launcher-1.11.3.jar",
    )
    http_file(
        name = "org_junit_platform_junit_platform_reporting_1_11_3",
        sha256 = "b8e19dbebcae7d1ff30b9d767047fbf3694027c33dfa423b371693b7f6679ed1",
        urls = ["https://repo1.maven.org/maven2/org/junit/platform/junit-platform-reporting/1.11.3/junit-platform-reporting-1.11.3.jar"],
        downloaded_file_path = "v1/org/junit/platform/junit-platform-reporting/1.11.3/junit-platform-reporting-1.11.3.jar",
    )
    http_file(
        name = "org_junit_vintage_junit_vintage_engine_5_11_3",
        sha256 = "d58022419bc76b3df4f479a2b3599d95e24464cd68fb7c2267f1a1a871215c47",
        urls = ["https://repo1.maven.org/maven2/org/junit/vintage/junit-vintage-engine/5.11.3/junit-vintage-engine-5.11.3.jar"],
        downloaded_file_path = "v1/org/junit/vintage/junit-vintage-engine/5.11.3/junit-vintage-engine-5.11.3.jar",
    )
    http_file(
        name = "org_mozilla_rhino_1_7_15",
        sha256 = "2427fdcbc149ca0a25ccfbb7c71b01f39ad42708773a47816cd2342861766b63",
        urls = ["https://repo1.maven.org/maven2/org/mozilla/rhino/1.7.15/rhino-1.7.15.jar"],
        downloaded_file_path = "v1/org/mozilla/rhino/1.7.15/rhino-1.7.15.jar",
    )
    http_file(
        name = "org_opentest4j_opentest4j_1_3_0",
        sha256 = "48e2df636cab6563ced64dcdff8abb2355627cb236ef0bf37598682ddf742f1b",
        urls = ["https://repo1.maven.org/maven2/org/opentest4j/opentest4j/1.3.0/opentest4j-1.3.0.jar"],
        downloaded_file_path = "v1/org/opentest4j/opentest4j/1.3.0/opentest4j-1.3.0.jar",
    )
    http_file(
        name = "org_ow2_asm_asm_9_7",
        sha256 = "adf46d5e34940bdf148ecdd26a9ee8eea94496a72034ff7141066b3eea5c4e9d",
        urls = ["https://repo1.maven.org/maven2/org/ow2/asm/asm/9.7/asm-9.7.jar"],
        downloaded_file_path = "v1/org/ow2/asm/asm/9.7/asm-9.7.jar",
    )
    http_file(
        name = "org_ow2_asm_asm_analysis_9_7",
        sha256 = "7bc6bcbc21379948a0c8c467fb0f864206e5b818f6bc0b546872f5c9f941556f",
        urls = ["https://repo1.maven.org/maven2/org/ow2/asm/asm-analysis/9.7/asm-analysis-9.7.jar"],
        downloaded_file_path = "v1/org/ow2/asm/asm-analysis/9.7/asm-analysis-9.7.jar",
    )
    http_file(
        name = "org_ow2_asm_asm_commons_9_7",
        sha256 = "389bc247958e049fc9a0408d398c92c6d370c18035120395d4cba1d9d9304b7a",
        urls = ["https://repo1.maven.org/maven2/org/ow2/asm/asm-commons/9.7/asm-commons-9.7.jar"],
        downloaded_file_path = "v1/org/ow2/asm/asm-commons/9.7/asm-commons-9.7.jar",
    )
    http_file(
        name = "org_ow2_asm_asm_tree_9_7",
        sha256 = "62f4b3bc436045c1acb5c3ba2d8ec556ec3369093d7f5d06c747eb04b56d52b1",
        urls = ["https://repo1.maven.org/maven2/org/ow2/asm/asm-tree/9.7/asm-tree-9.7.jar"],
        downloaded_file_path = "v1/org/ow2/asm/asm-tree/9.7/asm-tree-9.7.jar",
    )
    http_file(
        name = "org_ow2_asm_asm_util_9_7",
        sha256 = "37a6414d36641973f1af104937c95d6d921b2ddb4d612c66c5a9f2b13fc14211",
        urls = ["https://repo1.maven.org/maven2/org/ow2/asm/asm-util/9.7/asm-util-9.7.jar"],
        downloaded_file_path = "v1/org/ow2/asm/asm-util/9.7/asm-util-9.7.jar",
    )
    http_file(
        name = "org_pcollections_pcollections_4_0_2",
        sha256 = "2bbeef5797a241300c4f7513cd546239629ed7deda4fc0c31df90bb95f5f13ef",
        urls = ["https://repo1.maven.org/maven2/org/pcollections/pcollections/4.0.2/pcollections-4.0.2.jar"],
        downloaded_file_path = "v1/org/pcollections/pcollections/4.0.2/pcollections-4.0.2.jar",
    )
    http_file(
        name = "org_reflections_reflections_0_10_2",
        sha256 = "938a2d08fe54050d7610b944d8ddc3a09355710d9e6be0aac838dbc04e9a2825",
        urls = ["https://repo1.maven.org/maven2/org/reflections/reflections/0.10.2/reflections-0.10.2.jar"],
        downloaded_file_path = "v1/org/reflections/reflections/0.10.2/reflections-0.10.2.jar",
    )
    http_file(
        name = "org_scala_js_scalajs_stubs_2_13_1_0_0",
        sha256 = "60a58e75030081111da2e96e70140e6e370f2d1db7a353fe065b62eb757f82e3",
        urls = ["https://repo1.maven.org/maven2/org/scala-js/scalajs-stubs_2.13/1.0.0/scalajs-stubs_2.13-1.0.0.jar"],
        downloaded_file_path = "v1/org/scala-js/scalajs-stubs_2.13/1.0.0/scalajs-stubs_2.13-1.0.0.jar",
    )
    http_file(
        name = "org_scala_lang_modules_scala_collection_compat_2_13_2_8_1",
        sha256 = "9b8cc6028dab5813fe751950382499d655fe8777e2c4b07368eaa9d1116e049c",
        urls = ["https://repo1.maven.org/maven2/org/scala-lang/modules/scala-collection-compat_2.13/2.8.1/scala-collection-compat_2.13-2.8.1.jar"],
        downloaded_file_path = "v1/org/scala-lang/modules/scala-collection-compat_2.13/2.8.1/scala-collection-compat_2.13-2.8.1.jar",
    )
    http_file(
        name = "org_scala_lang_modules_scala_parallel_collections_2_13_1_0_0",
        sha256 = "fc08be49e91db44d7fe5c1ff95a322ad4500805a525cc2c4b1b91693f041c8e4",
        urls = ["https://repo1.maven.org/maven2/org/scala-lang/modules/scala-parallel-collections_2.13/1.0.0/scala-parallel-collections_2.13-1.0.0.jar"],
        downloaded_file_path = "v1/org/scala-lang/modules/scala-parallel-collections_2.13/1.0.0/scala-parallel-collections_2.13-1.0.0.jar",
    )
    http_file(
        name = "org_scala_lang_modules_scala_xml_2_13_1_3_0",
        sha256 = "6d96d45a7fc6fc7ab69bdbac841b48cf67ab109f048c8db375ae4effae524f39",
        urls = ["https://repo1.maven.org/maven2/org/scala-lang/modules/scala-xml_2.13/1.3.0/scala-xml_2.13-1.3.0.jar"],
        downloaded_file_path = "v1/org/scala-lang/modules/scala-xml_2.13/1.3.0/scala-xml_2.13-1.3.0.jar",
    )
    http_file(
        name = "org_scala_lang_scala_library_2_13_17",
        sha256 = "b7822c4225243215f185925724a6edff92cf18777a136cc738276c4446fac76c",
        urls = ["https://repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.17/scala-library-2.13.17.jar"],
        downloaded_file_path = "v1/org/scala-lang/scala-library/2.13.17/scala-library-2.13.17.jar",
    )
    http_file(
        name = "org_scala_lang_scala_reflect_2_13_10",
        sha256 = "62bd7a7198193c5373a992c122990279e413af3307162472a5d3cbb8ecadb35e",
        urls = ["https://repo1.maven.org/maven2/org/scala-lang/scala-reflect/2.13.10/scala-reflect-2.13.10.jar"],
        downloaded_file_path = "v1/org/scala-lang/scala-reflect/2.13.10/scala-reflect-2.13.10.jar",
    )
    http_file(
        name = "org_scalameta_common_2_13_4_14_1",
        sha256 = "608dcdddfac03bc57f0c131147a2e863a92061e112306a28d19ee850cff780e1",
        urls = ["https://repo1.maven.org/maven2/org/scalameta/common_2.13/4.14.1/common_2.13-4.14.1.jar"],
        downloaded_file_path = "v1/org/scalameta/common_2.13/4.14.1/common_2.13-4.14.1.jar",
    )
    http_file(
        name = "org_scalameta_io_2_13_4_14_1",
        sha256 = "8dd07edccd52fb43889f0f6e441e42d6a780ffd36e6328eb778327b7dbc75c9a",
        urls = ["https://repo1.maven.org/maven2/org/scalameta/io_2.13/4.14.1/io_2.13-4.14.1.jar"],
        downloaded_file_path = "v1/org/scalameta/io_2.13/4.14.1/io_2.13-4.14.1.jar",
    )
    http_file(
        name = "org_scalameta_parsers_2_13_4_14_1",
        sha256 = "bb2d75f14d3c235084269c65bad1d932e3dac6efa0027a2523aa1c2114731ded",
        urls = ["https://repo1.maven.org/maven2/org/scalameta/parsers_2.13/4.14.1/parsers_2.13-4.14.1.jar"],
        downloaded_file_path = "v1/org/scalameta/parsers_2.13/4.14.1/parsers_2.13-4.14.1.jar",
    )
    http_file(
        name = "org_scalameta_trees_2_13_4_14_1",
        sha256 = "c4a41e183ac57a4e3845e32818365a0a164e084f83fc65303452b623c543d7d1",
        urls = ["https://repo1.maven.org/maven2/org/scalameta/trees_2.13/4.14.1/trees_2.13-4.14.1.jar"],
        downloaded_file_path = "v1/org/scalameta/trees_2.13/4.14.1/trees_2.13-4.14.1.jar",
    )
    http_file(
        name = "org_slf4j_jul_to_slf4j_1_7_36",
        sha256 = "9e641fb142c5f0b0623d6222c09ea87523a41bf6bed48ac79940724010b989de",
        urls = ["https://repo1.maven.org/maven2/org/slf4j/jul-to-slf4j/1.7.36/jul-to-slf4j-1.7.36.jar"],
        downloaded_file_path = "v1/org/slf4j/jul-to-slf4j/1.7.36/jul-to-slf4j-1.7.36.jar",
    )
    http_file(
        name = "org_slf4j_slf4j_api_1_7_32",
        sha256 = "3624f8474c1af46d75f98bc097d7864a323c81b3808aa43689a6e1c601c027be",
        urls = ["https://repo1.maven.org/maven2/org/slf4j/slf4j-api/1.7.32/slf4j-api-1.7.32.jar"],
        downloaded_file_path = "v1/org/slf4j/slf4j-api/1.7.32/slf4j-api-1.7.32.jar",
    )
    http_file(
        name = "org_slf4j_slf4j_jdk14_1_7_32",
        sha256 = "4e09fd5ace1d3e5d1c9571b8eb7b17a23149e5ac322c11314c688991e2eb6f0b",
        urls = ["https://repo1.maven.org/maven2/org/slf4j/slf4j-jdk14/1.7.32/slf4j-jdk14-1.7.32.jar"],
        downloaded_file_path = "v1/org/slf4j/slf4j-jdk14/1.7.32/slf4j-jdk14-1.7.32.jar",
    )
    http_file(
        name = "org_slf4j_slf4j_simple_1_7_32",
        sha256 = "d2fdd7b73ca2019a2062d145a0d86179a58f98c8c3e35ca7c735a27b3b5621c3",
        urls = ["https://repo1.maven.org/maven2/org/slf4j/slf4j-simple/1.7.32/slf4j-simple-1.7.32.jar"],
        downloaded_file_path = "v1/org/slf4j/slf4j-simple/1.7.32/slf4j-simple-1.7.32.jar",
    )
    http_file(
        name = "org_xmlresolver_xmlresolver_jar_data_5_2_2",
        sha256 = "173904bdbd783ba0fac92c5bcc05da5d09f0ce7eed24346666ea0a239461f9b4",
        urls = ["https://repo1.maven.org/maven2/org/xmlresolver/xmlresolver/5.2.2/xmlresolver-5.2.2-data.jar"],
        downloaded_file_path = "v1/org/xmlresolver/xmlresolver/5.2.2/xmlresolver-5.2.2-data.jar",
    )
    http_file(
        name = "org_xmlresolver_xmlresolver_5_2_2",
        sha256 = "efc92bd7ed32b3e57095e0b3e872051ccfbbdcc980831ef33e89e38161a85222",
        urls = ["https://repo1.maven.org/maven2/org/xmlresolver/xmlresolver/5.2.2/xmlresolver-5.2.2.jar"],
        downloaded_file_path = "v1/org/xmlresolver/xmlresolver/5.2.2/xmlresolver-5.2.2.jar",
    )
maven_artifacts = [
    "com.github.nawforce:scala-json-rpc-upickle-json-serializer_2.13:1.1.0",
    "com.github.nawforce:scala-json-rpc_2.13:1.1.0",
    "com.github.oowekyala.ooxml:nice-xml-messages:3.1",
    "com.github.pathikrit:better-files_2.13:3.9.2",
    "com.github.spotbugs:spotbugs:4.8.6",
    "com.github.spotbugs:spotbugs-annotations:4.8.6",
    "com.github.stephenc.jcip:jcip-annotations:1.0-1",
    "com.google.android:annotations:4.1.1.4",
    "com.google.api.grpc:proto-google-common-protos:2.9.0",
    "com.google.code.findbugs:jsr305:3.0.2",
    "com.google.code.gson:gson:2.11.0",
    "com.google.errorprone:error_prone_annotations:2.35.1",
    "com.google.flogger:flogger:0.8",
    "com.google.flogger:flogger-system-backend:0.8",
    "com.google.googlejavaformat:google-java-format:1.24.0",
    "com.google.guava:failureaccess:1.0.1",
    "com.google.guava:guava:33.3.1-jre",
    "com.google.guava:listenablefuture:9999.0-empty-to-avoid-conflict-with-guava",
    "com.google.j2objc:j2objc-annotations:3.0.0",
    "com.google.protobuf:protobuf-java:3.21.7",
    "com.google.protobuf:protobuf-java-util:3.25.5",
    "com.google.summit:summit-ast:2.4.0",
    "com.lihaoyi:geny_2.13:0.6.2",
    "com.lihaoyi:mainargs_2.13:0.5.4",
    "com.lihaoyi:sourcecode_2.13:0.4.4",
    "com.lihaoyi:ujson_2.13:1.2.0",
    "com.lihaoyi:upack_2.13:1.2.0",
    "com.lihaoyi:upickle-core_2.13:1.2.0",
    "com.lihaoyi:upickle-implicits_2.13:1.2.0",
    "com.lihaoyi:upickle_2.13:1.2.0",
    "com.puppycrawl.tools:checkstyle:10.20.2",
    "commons-beanutils:commons-beanutils:1.9.4",
    "commons-cli:commons-cli:1.9.0",
    "commons-codec:commons-codec:1.15",
    "commons-collections:commons-collections:3.2.2",
    "commons-logging:commons-logging:1.2",
    "info.picocli:picocli:4.7.6",
    "io.github.apex-dev-tools:apex-ls_2.13:6.0.1",
    "io.github.apex-dev-tools:apex-parser:4.4.1",
    "io.github.apex-dev-tools:apex-types_2.13:1.3.0",
    "io.github.apex-dev-tools:outline-parser_2.13:1.3.0",
    "io.github.apex-dev-tools:sobject-types:65.0.0",
    "io.github.apex-dev-tools:standard-types:65.0.0",
    "io.github.apex-dev-tools:vf-parser:1.1.0",
    "io.grpc:grpc-api:1.68.2",
    "io.grpc:grpc-context:1.68.2",
    "io.grpc:grpc-core:1.68.2",
    "io.grpc:grpc-netty:1.68.2",
    "io.grpc:grpc-protobuf:1.68.2",
    "io.grpc:grpc-protobuf-lite:1.68.2",
    "io.grpc:grpc-services:1.68.2",
    "io.grpc:grpc-stub:1.68.2",
    "io.grpc:grpc-util:1.68.2",
    "io.methvin:directory-watcher:0.18.0",
    "io.methvin:directory-watcher-better-files_2.13:0.18.0",
    "io.netty:netty-buffer:4.1.110.Final",
    "io.netty:netty-codec:4.1.110.Final",
    "io.netty:netty-codec-http:4.1.110.Final",
    "io.netty:netty-codec-http2:4.1.110.Final",
    "io.netty:netty-codec-socks:4.1.110.Final",
    "io.netty:netty-common:4.1.110.Final",
    "io.netty:netty-handler:4.1.110.Final",
    "io.netty:netty-handler-proxy:4.1.110.Final",
    "io.netty:netty-resolver:4.1.110.Final",
    "io.netty:netty-transport:4.1.110.Final",
    "io.netty:netty-transport-native-unix-common:4.1.110.Final",
    "io.perfmark:perfmark-api:0.27.0",
    "javax.annotation:jsr250-api:1.0",
    "jaxen:jaxen:2.0.0",
    "junit:junit:4.13.2",
    "me.tongfei:progressbar:0.9.5",
    "net.java.dev.jna:jna:5.12.1",
    "net.sf.saxon:Saxon-HE:12.4",
    "net.sourceforge.pmd:pmd-ant:7.18.0",
    "net.sourceforge.pmd:pmd-apex:7.18.0",
    "net.sourceforge.pmd:pmd-cli:7.18.0",
    "net.sourceforge.pmd:pmd-coco:7.18.0",
    "net.sourceforge.pmd:pmd-core:7.18.0",
    "net.sourceforge.pmd:pmd-cpp:7.18.0",
    "net.sourceforge.pmd:pmd-cs:7.18.0",
    "net.sourceforge.pmd:pmd-css:7.18.0",
    "net.sourceforge.pmd:pmd-dart:7.18.0",
    "net.sourceforge.pmd:pmd-designer:7.10.0",
    "net.sourceforge.pmd:pmd-dist:7.18.0",
    "net.sourceforge.pmd:pmd-fortran:7.18.0",
    "net.sourceforge.pmd:pmd-gherkin:7.18.0",
    "net.sourceforge.pmd:pmd-go:7.18.0",
    "net.sourceforge.pmd:pmd-groovy:7.18.0",
    "net.sourceforge.pmd:pmd-html:7.18.0",
    "net.sourceforge.pmd:pmd-java:7.18.0",
    "net.sourceforge.pmd:pmd-javascript:7.18.0",
    "net.sourceforge.pmd:pmd-jsp:7.18.0",
    "net.sourceforge.pmd:pmd-julia:7.18.0",
    "net.sourceforge.pmd:pmd-kotlin:7.18.0",
    "net.sourceforge.pmd:pmd-lua:7.18.0",
    "net.sourceforge.pmd:pmd-matlab:7.18.0",
    "net.sourceforge.pmd:pmd-modelica:7.18.0",
    "net.sourceforge.pmd:pmd-objectivec:7.18.0",
    "net.sourceforge.pmd:pmd-perl:7.18.0",
    "net.sourceforge.pmd:pmd-php:7.18.0",
    "net.sourceforge.pmd:pmd-plsql:7.18.0",
    "net.sourceforge.pmd:pmd-python:7.18.0",
    "net.sourceforge.pmd:pmd-ruby:7.18.0",
    "net.sourceforge.pmd:pmd-rust:7.18.0",
    "net.sourceforge.pmd:pmd-scala_2.13:7.18.0",
    "net.sourceforge.pmd:pmd-swift:7.18.0",
    "net.sourceforge.pmd:pmd-tsql:7.18.0",
    "net.sourceforge.pmd:pmd-velocity:7.18.0",
    "net.sourceforge.pmd:pmd-visualforce:7.18.0",
    "net.sourceforge.pmd:pmd-xml:7.18.0",
    "org.antlr:antlr4-runtime:4.13.2",
    "org.apache.bcel:bcel:6.9.0",
    "org.apache.commons:commons-lang3:3.14.0",
    "org.apache.commons:commons-text:1.10.0",
    "org.apache.groovy:groovy:5.0.2",
    "org.apache.httpcomponents.client5:httpclient5:5.1.3",
    "org.apache.httpcomponents.core5:httpcore5:5.1.3",
    "org.apache.httpcomponents.core5:httpcore5-h2:5.1.3",
    "org.apache.httpcomponents:httpclient:4.5.13",
    "org.apache.httpcomponents:httpcore:4.4.14",
    "org.apache.logging.log4j:log4j-api:2.23.1",
    "org.apache.logging.log4j:log4j-core:2.23.1",
    "org.apache.maven.doxia:doxia-core:1.12.0",
    "org.apache.maven.doxia:doxia-logging-api:1.12.0",
    "org.apache.maven.doxia:doxia-module-xdoc:1.12.0",
    "org.apache.maven.doxia:doxia-sink-api:1.12.0",
    "org.apache.tomcat:annotations-api:6.0.53",
    "org.apache.xbean:xbean-reflect:3.7",
    "org.apiguardian:apiguardian-api:1.1.2",
    "org.checkerframework:checker-compat-qual:2.5.3",
    "org.checkerframework:checker-qual:3.43.0",
    "org.codehaus.mojo:animal-sniffer-annotations:1.21",
    "org.codehaus.plexus:plexus-classworlds:2.6.0",
    "org.codehaus.plexus:plexus-component-annotations:2.1.0",
    "org.codehaus.plexus:plexus-container-default:2.1.0",
    "org.codehaus.plexus:plexus-utils:3.3.0",
    "org.danilopianini:gson-extras:1.3.0",
    "org.dom4j:dom4j:2.1.4",
    "org.hamcrest:hamcrest-core:1.3",
    "org.javassist:javassist:3.28.0-GA",
    "org.jetbrains.kotlin:kotlin-compiler:2.2.20",
    "org.jetbrains.kotlin:kotlin-reflect:1.6.10",
    "org.jetbrains.kotlin:kotlin-script-runtime:2.2.20",
    "org.jetbrains.kotlin:kotlin-stdlib:2.2.20",
    "org.jetbrains.kotlin:kotlin-stdlib-jdk7:2.2.20",
    "org.jetbrains.kotlin:kotlin-stdlib-jdk8:2.2.20",
    "org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm:1.8.0",
    "org.jetbrains:annotations:23.0.0",
    "org.jline:jline:3.21.0",
    "org.jsoup:jsoup:1.21.2",
    "org.junit.jupiter:junit-jupiter-api:5.11.3",
    "org.junit.jupiter:junit-jupiter-engine:5.11.3",
    "org.junit.platform:junit-platform-commons:1.11.3",
    "org.junit.platform:junit-platform-engine:1.11.3",
    "org.junit.platform:junit-platform-launcher:1.11.3",
    "org.junit.platform:junit-platform-reporting:1.11.3",
    "org.junit.vintage:junit-vintage-engine:5.11.3",
    "org.mozilla:rhino:1.7.15",
    "org.opentest4j:opentest4j:1.3.0",
    "org.ow2.asm:asm:9.7",
    "org.ow2.asm:asm-analysis:9.7",
    "org.ow2.asm:asm-commons:9.7",
    "org.ow2.asm:asm-tree:9.7",
    "org.ow2.asm:asm-util:9.7",
    "org.pcollections:pcollections:4.0.2",
    "org.reflections:reflections:0.10.2",
    "org.scala-js:scalajs-stubs_2.13:1.0.0",
    "org.scala-lang.modules:scala-collection-compat_2.13:2.8.1",
    "org.scala-lang.modules:scala-parallel-collections_2.13:1.0.0",
    "org.scala-lang.modules:scala-xml_2.13:1.3.0",
    "org.scala-lang:scala-library:2.13.17",
    "org.scala-lang:scala-reflect:2.13.10",
    "org.scalameta:common_2.13:4.14.1",
    "org.scalameta:io_2.13:4.14.1",
    "org.scalameta:parsers_2.13:4.14.1",
    "org.scalameta:trees_2.13:4.14.1",
    "org.slf4j:jul-to-slf4j:1.7.36",
    "org.slf4j:slf4j-api:1.7.32",
    "org.slf4j:slf4j-jdk14:1.7.32",
    "org.slf4j:slf4j-simple:1.7.32",
    "org.xmlresolver:xmlresolver:jar:data:5.2.2",
    "org.xmlresolver:xmlresolver:5.2.2"
]